#ifndef BOX_CPP
#define BOX_CPP 
#include "Box.h"

Box::Box(){};
void Box::setVolume(double input_volume){
    this->volume = input_volume;
}
#endif